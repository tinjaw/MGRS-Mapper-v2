// ADD THE 100K GRID SQUARES TO INDEXEDDB
console.time('compile time');
fetch('./gridHelper/cornerGrids.min.json')
  .then((data) => data.json())
  .then((data) => {
    // Object.assign(emptyObj2, data);
    let db;
    const request = indexedDB.open('GridDB', 1);
    const gzdID = Object.getOwnPropertyNames(data);

    request.onupgradeneeded = (event) => {
      db = event.target.result;
      if (!db.objectStoreNames.contains('Grids100K')) {
        db.createObjectStore('Grids100K', {
          autoIncrement: true,
          keyPath: 'id',
        });
      }
    };

    request.onsuccess = () => {
      gzdID.map((e, i) => {
        db = request.result;
        db.transaction('Grids100K', 'readwrite')
          .objectStore(['Grids100K'])
          .add({
            id: e,
            [e]: Object.entries(data)[i][1],
          });
      });
    };

    request.onerror = (event) => {
      console.log('The database is opened failed');
      console.log(event.target.error);
    };

    console.timeEnd('compile time'); // 609 ms
  })
  .catch((err) => console.error(err));
